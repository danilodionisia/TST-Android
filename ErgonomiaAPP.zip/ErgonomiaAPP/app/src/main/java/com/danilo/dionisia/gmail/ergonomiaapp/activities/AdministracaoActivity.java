package com.danilo.dionisia.gmail.ergonomiaapp.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.danilo.dionisia.gmail.ergonomiaapp.R;

public class AdministracaoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_administracao);
    }
}
