package com.danilo.dionisia.gmail.ergonomiaapp.frames;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.danilo.dionisia.gmail.ergonomiaapp.R;
import com.danilo.dionisia.gmail.ergonomiaapp.model.Registros;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * A simple {@link Fragment} subclass.
 */
public class RegistroFragment extends Fragment {

    private Button buttonRegistraEntrada, buttonRegistraSaida;
    private EditText editTextRegistro;
    private DatabaseReference reference;
    private TextView textViewSetor;

    public RegistroFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragment_registro, container, false);

        editTextRegistro = view.findViewById(R.id.editTextRegistro);
        buttonRegistraEntrada = view.findViewById(R.id.buttonRegistrarEntrada);
        buttonRegistraSaida = view.findViewById(R.id.buttonRegistrarSaida);
        textViewSetor = view.findViewById(R.id.textViewSetor);

        editTextRegistro.requestFocus();

        buttonRegistraEntrada.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (editTextRegistro.getText().toString().isEmpty()){
                    Toast.makeText(view.getContext(), "Preencha o campo identificação!", Toast.LENGTH_SHORT).show();
                    editTextRegistro.requestFocus();
                }else{

                    Date date = new Date();
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(date);
                    int hours = cal.get(Calendar.HOUR_OF_DAY);
                   // hours = hours - 3;
                    int minutes = cal.get(Calendar.MINUTE);

                    reference = FirebaseDatabase.getInstance().getReference("Registros");
                    DatabaseReference ref = reference.child("Registros");

                    Registros registros = new Registros();

                    registros.setIdentificacao(editTextRegistro.getText().toString());
                    registros.setSetor(textViewSetor.getText().toString());
                    registros.setTipo("Entrada");
                    registros.setHora(String.valueOf(hours) + ":" + String.valueOf(minutes));

                    reference.push().setValue(registros);
                    buttonRegistraEntrada.setEnabled(false);
                    editTextRegistro.setEnabled(false);

                }

            }
        });

        buttonRegistraSaida.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editTextRegistro.getText().toString().isEmpty()){
                    Toast.makeText(view.getContext(), "Preencha o campo identificação!", Toast.LENGTH_SHORT).show();
                    editTextRegistro.requestFocus();
                }else{

                    Date date = new Date();
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(date);
                    int hours = cal.get(Calendar.HOUR_OF_DAY);
                    //hours = hours - 3;
                    int minutes = cal.get(Calendar.MINUTE);

                    reference = FirebaseDatabase.getInstance().getReference("Registros");
                    DatabaseReference ref = reference.child("Registros");

                    Registros registros = new Registros();

                    registros.setIdentificacao(editTextRegistro.getText().toString());
                    registros.setSetor(textViewSetor.getText().toString());
                    registros.setTipo("Saída");
                    registros.setHora(String.valueOf(hours) + ":" + String.valueOf(minutes));

                    reference.push().setValue(registros);
                    buttonRegistraEntrada.setEnabled(true);
                    editTextRegistro.setEnabled(true);
                    editTextRegistro.setText("");
                    editTextRegistro.requestFocus();
                }

            }
        });

        return view;
    }

}
