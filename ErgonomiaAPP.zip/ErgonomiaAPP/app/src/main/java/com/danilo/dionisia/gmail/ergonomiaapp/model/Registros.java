package com.danilo.dionisia.gmail.ergonomiaapp.model;

public class Registros {

    private String Identificacao, Setor, Tipo, Hora;

    public String getIdentificacao() {
        return Identificacao;
    }

    public void setIdentificacao(String identificacao) {
        Identificacao = identificacao;
    }

    public String getSetor() {
        return Setor;
    }

    public void setSetor(String setor) {
        Setor = setor;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String tipo) {
        Tipo = tipo;
    }

    public String getHora() {
        return Hora;
    }

    public void setHora(String hora) {
        Hora = hora;
    }
}
