package com.danilo.dionisia.gmail.ergonomiaapp.activities;

import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.danilo.dionisia.gmail.ergonomiaapp.R;
import com.danilo.dionisia.gmail.ergonomiaapp.frames.AdministracaoFragment;
import com.danilo.dionisia.gmail.ergonomiaapp.frames.RegistroFragment;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    DatabaseReference databaseReference;

    private RegistroFragment registroFragment;
    private AdministracaoFragment administracaoFragment;
    private Button buttonRegistro, buttonAdministracao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonRegistro = findViewById(R.id.buttonRegistrar);
        buttonAdministracao = findViewById(R.id.buttonAdministrador);

        registroFragment = new RegistroFragment();
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frameLayoutContainer, registroFragment);
        transaction.commit();

        buttonRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                registroFragment = new RegistroFragment();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frameLayoutContainer, registroFragment);
                transaction.commit();

            }
        });

        buttonAdministracao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                administracaoFragment = new AdministracaoFragment();
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.frameLayoutContainer, administracaoFragment);
                transaction.commit();
            }
        });

    }
}
