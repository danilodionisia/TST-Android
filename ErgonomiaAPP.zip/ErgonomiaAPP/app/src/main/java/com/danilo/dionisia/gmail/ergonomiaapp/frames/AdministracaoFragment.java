package com.danilo.dionisia.gmail.ergonomiaapp.frames;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.danilo.dionisia.gmail.ergonomiaapp.R;
import com.danilo.dionisia.gmail.ergonomiaapp.activities.AdministracaoActivity;

/**
 * A simple {@link Fragment} subclass.
 */
public class AdministracaoFragment extends Fragment {

    private Button buttonOK;
    private EditText editTextLogin, editTextPassword;

    public AdministracaoFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragment_administracao, container, false);

        editTextLogin = view.findViewById(R.id.editTextLogin);
        editTextPassword = view.findViewById(R.id.editTextPassword);
        buttonOK = view.findViewById(R.id.buttonOK);

        editTextLogin.requestFocus();

        buttonOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editTextLogin.getText().toString().isEmpty()){
                    Toast.makeText(view.getContext(), "Preencha o campo Login", Toast.LENGTH_SHORT).show();
                    editTextLogin.requestFocus();
                }else if(editTextPassword.getText().toString().isEmpty()){
                    Toast.makeText(view.getContext(), "Preencha o campos Senha!", Toast.LENGTH_SHORT).show();
                    editTextPassword.requestFocus();
                }else{
                    //if (editTextLogin.getText().toString() == "admin" && editTextPassword.getText().toString() == "admin") {
                    if (2==2) {
                        editTextLogin.setText("");
                        editTextPassword.setText("");
                        Intent intent = new Intent(view.getContext(), AdministracaoActivity.class);
                        startActivity(intent);
                    }else{
                        Toast.makeText(view.getContext(), "Login e/ou Senha incorreto(s)", Toast.LENGTH_SHORT).show();
                        editTextLogin.requestFocus();
                    }
                }
            }
        });

        return view;
    }

}
